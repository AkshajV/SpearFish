// internal/database/jobs_query.go
package database

import (
	"context"
	"fmt"
	"strings"

	"github.com/google/uuid"
	"github.com/jackc/pgx/v5/pgxpool"
)

type Job struct {
	ID              uuid.UUID `json:"id"`
	JobTitle        string    `json:"job_title"`
	CompanyName     string    `json:"company_name"`
	Location        string    `json:"location"`
	Description     string    `json:"description"`
	JobURL          string    `json:"job_url"`
	ExperienceMin   int       `json:"experience_min"`
	ExperienceMax   int       `json:"experience_max"`
	ExperienceLevel string    `json:"experience_level"`
	Source          string    `json:"source"`
}

// Updated GetJobs to accept an excludeCompany string
func GetJobs(pool *pgxpool.Pool, limit, offset int, search string, minExp, maxExp int, location string, excludeCompany string) ([]Job, error) {
	ctx := context.Background()

	baseQuery := `
		SELECT j.id, j.job_title, c.name, j.location, j.description,
		       j.job_url, j.experience_min, j.experience_max, j.experience_level, j.source
		FROM jobs j
		JOIN companies c ON j.company_id = c.id
	`

	var whereClauses []string
	var args []interface{}
	argID := 1

	if search != "" {
		whereClauses = append(whereClauses, fmt.Sprintf("LOWER(j.job_title) LIKE $%d", argID))
		args = append(args, "%"+strings.ToLower(search)+"%")
		argID++
	}

	if location != "" {
		// Strip accidental spaces from the frontend payload
		cleanLoc := strings.TrimSpace(location)

		// The classic Bangalore vs Bengaluru catch
		if strings.EqualFold(cleanLoc, "bengaluru") || strings.EqualFold(cleanLoc, "bangalore") {
			whereClauses = append(whereClauses, fmt.Sprintf("(j.location ILIKE $%d OR j.location ILIKE $%d)", argID, argID+1))
			args = append(args, "%bengaluru%", "%bangalore%")
			argID += 2
		} else {
			// ILIKE handles the case-insensitivity natively in Postgres without needing LOWER()
			whereClauses = append(whereClauses, fmt.Sprintf("j.location ILIKE $%d", argID))
			args = append(args, "%"+cleanLoc+"%")
			argID++
		}
	}

	// The Exclusion Filter (e.g., "PwC, EY")
	if excludeCompany != "" {
		excludes := strings.Split(excludeCompany, ",")
		for _, ex := range excludes {
			cleanEx := strings.TrimSpace(ex)
			if cleanEx != "" {
				whereClauses = append(whereClauses, fmt.Sprintf("LOWER(c.name) NOT LIKE $%d", argID))
				args = append(args, "%"+strings.ToLower(cleanEx)+"%")
				argID++
			}
		}
	}

	if minExp >= 0 {
		whereClauses = append(whereClauses, fmt.Sprintf("j.experience_max >= $%d", argID))
		args = append(args, minExp)
		argID++
	}
	if maxExp >= 0 {
		whereClauses = append(whereClauses, fmt.Sprintf("j.experience_min <= $%d", argID))
		args = append(args, maxExp)
		argID++
	}

	if len(whereClauses) > 0 {
		baseQuery += " WHERE " + strings.Join(whereClauses, " AND ")
	}

	baseQuery += fmt.Sprintf(" ORDER BY j.created_at DESC LIMIT $%d OFFSET $%d", argID, argID+1)
	args = append(args, limit, offset)

	rows, err := pool.Query(ctx, baseQuery, args...)
	if err != nil {
		return nil, fmt.Errorf("failed to query jobs: %w", err)
	}
	defer rows.Close()

	var jobs []Job
	for rows.Next() {
		var job Job
		err := rows.Scan(
			&job.ID, &job.JobTitle, &job.CompanyName, &job.Location,
			&job.Description, &job.JobURL, &job.ExperienceMin, &job.ExperienceMax,
			&job.ExperienceLevel, &job.Source,
		)
		if err != nil {
			return nil, fmt.Errorf("failed to scan job row: %w", err)
		}
		jobs = append(jobs, job)
	}
	return jobs, nil
}

// GetSavedJobs pulls only the jobs tracked by the specific user
func GetSavedJobs(pool *pgxpool.Pool, email string) ([]Job, error) {
	ctx := context.Background()

	// internal/database/jobs_query.go

	// Update the query inside GetSavedJobs to remove the reference to a.updated_at:
	query := `
			SELECT j.id, j.job_title, c.name, j.location, j.description,
			       j.job_url, j.experience_min, j.experience_max, j.experience_level, j.source
			FROM jobs j
			JOIN companies c ON j.company_id = c.id
			JOIN applications a ON j.id = a.job_id
			JOIN users u ON a.user_id = u.id
			WHERE u.email = $1 AND a.status = 'Saved'
			ORDER BY a.id DESC
		`

	rows, err := pool.Query(ctx, query, email)
	if err != nil {
		return nil, fmt.Errorf("failed to query saved jobs: %w", err)
	}
	defer rows.Close()

	var jobs []Job
	for rows.Next() {
		var job Job
		err := rows.Scan(
			&job.ID, &job.JobTitle, &job.CompanyName, &job.Location,
			&job.Description, &job.JobURL, &job.ExperienceMin, &job.ExperienceMax,
			&job.ExperienceLevel, &job.Source,
		)
		if err != nil {
			return nil, fmt.Errorf("failed to scan job row: %w", err)
		}
		jobs = append(jobs, job)
	}
	return jobs, nil
}
