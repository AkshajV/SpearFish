// internal/api/server.go
package api

import (
	"encoding/json"
	"log"
	"net/http"
	"strconv"
	"time"

	"github.com/AkshajV/SpearFish/internal/database"
	"github.com/google/uuid"
	"github.com/jackc/pgx/v5/pgxpool"
)

func StartServer(pool *pgxpool.Pool) {
	mux := http.NewServeMux()

	// 1. GET /api/jobs — Removed method prefix to allow global CORS processing
	mux.HandleFunc("/api/jobs", func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Access-Control-Allow-Origin", "http://localhost:3000")
		w.Header().Set("Access-Control-Allow-Methods", "GET, OPTIONS")
		w.Header().Set("Access-Control-Allow-Headers", "Content-Type")
		w.Header().Set("Content-Type", "application/json")

		if r.Method == "OPTIONS" {
			w.WriteHeader(http.StatusOK)
			return
		}

		q := r.URL.Query()

		limit := 20
		offset := 0
		minExp := -1
		maxExp := -1

		if v := q.Get("limit"); v != "" {
			if n, err := strconv.Atoi(v); err == nil && n > 0 {
				if n > 50 {
					limit = 50
				} else {
					limit = n
				}
			}
		}
		if v := q.Get("offset"); v != "" {
			if n, err := strconv.Atoi(v); err == nil && n >= 0 {
				offset = n
			}
		}
		if v := q.Get("min_exp"); v != "" {
			if n, err := strconv.Atoi(v); err == nil {
				minExp = n
			}
		}
		if v := q.Get("max_exp"); v != "" {
			if n, err := strconv.Atoi(v); err == nil {
				maxExp = n
			}
		}

		search := q.Get("search")
		location := q.Get("location")
		excludeCompany := q.Get("exclude_company")

		if len(search) > 100 {
			search = search[:100]
		}
		if len(location) > 50 {
			location = location[:50]
		}

		jobs, err := database.GetJobs(pool, limit, offset, search, minExp, maxExp, location, excludeCompany)
		if err != nil {
			http.Error(w, `{"error": "Internal server error"}`, http.StatusInternalServerError)
			return
		}

		if jobs == nil {
			jobs = []database.Job{}
		}
		json.NewEncoder(w).Encode(jobs)
	})

	// 2. GET /api/jobs/saved — Removed method prefix to avoid router preflight rejections
	mux.HandleFunc("/api/jobs/saved", AuthMiddleware(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Access-Control-Allow-Origin", "http://localhost:3000")
		w.Header().Set("Content-Type", "application/json")

		if r.Method == "OPTIONS" {
			w.WriteHeader(http.StatusOK)
			return
		}

		email := r.Context().Value(UserEmailKey).(string)

		jobs, err := database.GetSavedJobs(pool, email)
		if err != nil {
			http.Error(w, err.Error(), http.StatusInternalServerError)
			return
		}

		if jobs == nil {
			jobs = []database.Job{}
		}
		json.NewEncoder(w).Encode(jobs)
	}))

	// 3. POST /api/users/sync — Removed method prefix to gracefully absorb OPTIONS preflights
	mux.HandleFunc("/api/users/sync", func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Access-Control-Allow-Origin", "http://localhost:3000")
		w.Header().Set("Access-Control-Allow-Methods", "POST, OPTIONS")
		w.Header().Set("Access-Control-Allow-Headers", "Content-Type")
		w.Header().Set("Content-Type", "application/json")

		if r.Method == "OPTIONS" {
			w.WriteHeader(http.StatusOK)
			return
		}

		var payload struct {
			Email string `json:"email"`
		}
		if err := json.NewDecoder(r.Body).Decode(&payload); err != nil {
			http.Error(w, err.Error(), http.StatusBadRequest)
			return
		}

		_, err := database.EnsureUserExists(pool, payload.Email)
		if err != nil {
			http.Error(w, err.Error(), http.StatusInternalServerError)
			return
		}
		w.WriteHeader(http.StatusOK)
	})

	// 4. POST /api/jobs/track — Removed method prefix to allow AuthMiddleware handling preflights
	mux.HandleFunc("/api/jobs/track", AuthMiddleware(func(w http.ResponseWriter, r *http.Request) {
		// CORS headers are managed explicitly in AuthMiddleware for this route context
		if r.Method == "OPTIONS" {
			return
		}

		email := r.Context().Value(UserEmailKey).(string)

		var payload struct {
			JobID  string `json:"job_id"`
			Status string `json:"status"`
		}
		if err := json.NewDecoder(r.Body).Decode(&payload); err != nil {
			http.Error(w, err.Error(), http.StatusBadRequest)
			return
		}

		jobUUID, err := uuid.Parse(payload.JobID)
		if err != nil {
			http.Error(w, "Invalid Job ID formatting", http.StatusBadRequest)
			return
		}

		err = database.TrackJobApplication(pool, email, jobUUID, payload.Status)
		if err != nil {
			http.Error(w, err.Error(), http.StatusInternalServerError)
			return
		}

		w.WriteHeader(http.StatusOK)
	}))

	// DELETE /api/jobs/track -> Unsave a job role
	mux.HandleFunc("/api/jobs/unsave", AuthMiddleware(func(w http.ResponseWriter, r *http.Request) {
		if r.Method == "OPTIONS" {
			return
		}

		email := r.Context().Value(UserEmailKey).(string)

		var payload struct {
			JobID string `json:"job_id"`
		}
		if err := json.NewDecoder(r.Body).Decode(&payload); err != nil {
			http.Error(w, err.Error(), http.StatusBadRequest)
			return
		}

		jobUUID, err := uuid.Parse(payload.JobID)
		if err != nil {
			http.Error(w, "Invalid Job ID formatting", http.StatusBadRequest)
			return
		}

		err = database.UnarchiveJobApplication(pool, email, jobUUID)
		if err != nil {
			http.Error(w, err.Error(), http.StatusInternalServerError)
			return
		}

		w.WriteHeader(http.StatusOK)
	}))

	// POST /api/jobs/manual -> Add a custom job to the vault
	mux.HandleFunc("/api/jobs/manual", AuthMiddleware(func(w http.ResponseWriter, r *http.Request) {
		if r.Method == "OPTIONS" {
			return
		}

		email := r.Context().Value(UserEmailKey).(string)

		var payload struct {
			Title    string `json:"title"`
			Company  string `json:"company"`
			Location string `json:"location"`
			URL      string `json:"url"`
		}
		if err := json.NewDecoder(r.Body).Decode(&payload); err != nil {
			http.Error(w, err.Error(), http.StatusBadRequest)
			return
		}

		jobID, err := database.TrackManualJob(pool, email, payload.Title, payload.Company, payload.Location, payload.URL)
		if err != nil {
			http.Error(w, err.Error(), http.StatusInternalServerError)
			return
		}

		// Return the real database ID so the frontend can target it for deletion later
		w.Header().Set("Content-Type", "application/json")
		json.NewEncoder(w).Encode(map[string]string{"id": jobID.String()})
	}))

	// Define Server Configuration with Timeouts
	srv := &http.Server{
		Addr:         ":8080",
		Handler:      mux,
		ReadTimeout:  5 * time.Second,
		WriteTimeout: 10 * time.Second,
		IdleTimeout:  120 * time.Second,
	}

	log.Println("Secure API Server starting on :8080")
	log.Fatal(srv.ListenAndServe())
}
