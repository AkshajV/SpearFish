package ai

import (
	"context"
	"encoding/json"
	"fmt"
	"log"
	"strings"

	"github.com/google/generative-ai-go/genai"
	"github.com/jackc/pgx/v5/pgxpool"
	"google.golang.org/api/option"
)

// We force Gemini to return strict JSON so we can parse it instantly
type GeminiResponse struct {
	Score     int    `json:"score"`
	Reasoning string `json:"reasoning"`
}

func RunBatchScoring(db *pgxpool.Pool, apiKey string) {
	ctx := context.Background()

	// 1. Initialize Gemini Client
	client, err := genai.NewClient(ctx, option.WithAPIKey(apiKey))
	if err != nil {
		log.Fatalf("Failed to create Gemini client: %v", err)
	}
	defer client.Close()

	model := client.GenerativeModel("gemini-2.5-flash") // Fast and cheap for batch processing
	model.ResponseMIMEType = "application/json"

	// 2. Fetch jobs that haven't been scored yet
	rows, err := db.Query(ctx, `
		SELECT id, job_title, company_name, description
		FROM jobs
		WHERE ai_score = -1 AND description != ''
		LIMIT 10
	`) // Process in batches of 10 to respect API rate limits
	if err != nil {
		log.Fatalf("DB Query failed: %v", err)
	}
	defer rows.Close()

	// 3. Your core profile baseline
	userProfile := `
		Candidate Profile:
		- Final-year Computer and Communication Engineering student (Cybersecurity minor).
		- Currently working as a technical intern at an MNC.
		- Actively studying for the CompTIA Security+ (SY0-701) certification.
		- Primary career target: Governance, Risk, and Compliance (GRC), seeking stable, high-paying roles over heavily technical/operational security roles.
	`

	log.Println("Starting AI batch scoring...")

	for rows.Next() {
		var id, title, company, description string
		if err := rows.Scan(&id, &title, &company, &description); err != nil {
			continue
		}

		// 4. Construct the prompt
		prompt := fmt.Sprintf(`
			You are an expert tech recruiter. Evaluate this job against the candidate's profile.
			Return ONLY a valid JSON object with two keys:
			- "score": an integer from 0 to 100 representing how good of a match this is for the candidate. Rate GRC/Audit/Compliance roles highly. Rate highly technical deep-engineering roles lower.
			- "reasoning": A punchy, 1-sentence explanation of why you gave this score.

			%s

			Job Title: %s
			Company: %s
			Job Description: %s
		`, userProfile, title, company, description)

		// 5. Ask Gemini
		resp, err := model.GenerateContent(ctx, genai.Text(prompt))
		if err != nil {
			log.Printf("Gemini API error for job %s: %v", id, err)
			continue
		}

		// 6. Parse and Save
		if len(resp.Candidates) > 0 && len(resp.Candidates[0].Content.Parts) > 0 {
			rawJSON := fmt.Sprintf("%v", resp.Candidates[0].Content.Parts[0])

			// Clean markdown formatting if Gemini includes it
			rawJSON = strings.TrimPrefix(rawJSON, "```json\n")
			rawJSON = strings.TrimSuffix(rawJSON, "\n```")

			var aiResult GeminiResponse
			if err := json.Unmarshal([]byte(rawJSON), &aiResult); err == nil {
				// Update the database
				_, err = db.Exec(ctx, `
					UPDATE jobs SET ai_score = $1, ai_reasoning = $2 WHERE id = $3
				`, aiResult.Score, aiResult.Reasoning, id)

				if err == nil {
					log.Printf("✓ Scored %s @ %s: %d/100", title, company, aiResult.Score)
				}
			} else {
				log.Printf("Failed to parse JSON for %s: %v", id, err)
			}
		}
	}
	log.Println("Batch scoring complete!")
}
